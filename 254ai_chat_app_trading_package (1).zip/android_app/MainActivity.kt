package com.example.ai_chat_app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MainApp() }
    }
}

@Composable
fun MainApp() {
    var currentTab by remember { mutableStateOf(0) }
    val tabs = listOf("Chat", "Trading Assistant", "Settings")

    Scaffold(topBar = {
        TopAppBar(title = { Text("AI Assistant") })
    }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = currentTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = currentTab == index, onClick = { currentTab = index }, text = { Text(title) })
                }
            }
            when (currentTab) {
                0 -> ChatScreen()
                1 -> TradingAssistantScreen()
                2 -> SettingsScreen()
            }
        }
    }
}

// Simple storage using rememberSaveable for demo (replace with encrypted storage in production)
@Composable
fun SettingsScreen() {
    var apiKey by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("OpenAI API Key") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            // Save to OpenAIService (in-memory for demo). In production use encrypted storage.
            OpenAIService.init(apiKey)
        }) { Text("Save API Key") }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Note: For public distribution, use a backend proxy to keep your API key secret.")
    }
}

// Chat screen calls existing ChatApp-like logic (simplified)
@Composable
fun ChatScreen() {
    val coroutineScope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<String,String>>() }
    var loading by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Column(modifier = Modifier.weight(1f)) {
            for (m in messages) {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(text = m.first, style = MaterialTheme.typography.subtitle2)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = m.second, style = MaterialTheme.typography.body1)
                    }
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask anything") })
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = {
                val text = input.trim()
                if (text.isEmpty()) return@Button
                messages.add(Pair("You", text))
                input = ""
                loading = true
                coroutineScope.launch {
                    try {
                        val req = ChatRequest(messages = listOf(Message("system","You are a helpful assistant."), Message("user", text)))
                        val res = OpenAIService.api.createChat(req)
                        val aiText = res.choices?.firstOrNull()?.message?.content ?: "No response"
                        messages.add(Pair("AI", aiText))
                    } catch (e: Exception) {
                        messages.add(Pair("AI", "Error: ${e.message}"))
                    } finally {
                        loading = false
                    }
                }
            }) {
                Text(if (loading) "Waiting..." else "Send")
            }
        }
    }
}

// Trading assistant: asks for a symbol and returns a simple analysis using the model
@Composable
fun TradingAssistantScreen() {
    val coroutineScope = rememberCoroutineScope()
    var symbol by remember { mutableStateOf("") }
    var timeframe by remember { mutableStateOf("1h") }
    var result by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(value = symbol, onValueChange = { symbol = it }, label = { Text("Symbol (e.g., BTCUSD)") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = timeframe, onValueChange = { timeframe = it }, label = { Text("Timeframe") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {
            val s = symbol.trim()
            if (s.isEmpty()) return@Button
            loading = true
            coroutineScope.launch {
                try {
                    val prompt = "Provide a concise technical analysis for $s on timeframe $timeframe. Include trend, key levels, and a simple trade idea with risk management."
                    val req = ChatRequest(messages = listOf(Message("system","You are a financial assistant."), Message("user", prompt)))
                    val res = OpenAIService.api.createChat(req)
                    result = res.choices?.firstOrNull()?.message?.content ?: "No response"
                } catch (e: Exception) {
                    result = "Error: ${e.message}"
                } finally {
                    loading = false
                }
            }
        }, enabled = !loading) {
            Text(if (loading) "Analyzing..." else "Analyze") 
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(result)
        Spacer(modifier = Modifier.height(12.dp))
        Text("Warning: This is not financial advice. Backtest strategies and manage risk.")
    }
}
