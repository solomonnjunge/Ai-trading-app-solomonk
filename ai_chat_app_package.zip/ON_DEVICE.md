On-device LLM notes (advanced)
------------------------------
Running an LLM fully on-device avoids API keys and per-request costs but is advanced and resource-heavy.

Options:
1) llama.cpp / ggml builds for Android
   - You will need a quantized ggml model (e.g., Llama 2 7B quantized) converted to gguf/ggml format.
   - Build llama.cpp for Android (NDK) and call via JNI.
   - Pros: Offline, no recurring cost. Cons: Large downloads (hundreds of MB to GB), slower responses, engineering complexity.

2) Use smaller mobile-focused models (e.g., Mistral Tiny, Meta's smaller models, or LLMs in ONNX format)
   - Convert to TFLite / ONNX format and run with optimized runtimes.
   - Tools: ggml, llama.cpp, exllama, llama-rs, Hugging Face's transformers + converters.

Basic steps:
- Choose a quantized model and confirm license permits local use.
- Build native runtime for Android (C++ with NDK) or use existing wrappers.
- Package model files with the app (or download on first run) and load via JNI.
- Implement conversation management and tokenization on-device.

Warning: This requires strong familiarity with Android native development, cross-compilation, and model licensing.
