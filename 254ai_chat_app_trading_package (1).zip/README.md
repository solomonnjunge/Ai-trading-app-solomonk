AI Assistant (Chat + Trading) - Project Package
----------------------------------------------

What you get:
- android_app/: Android source (Jetpack Compose) with Chat + Trading Assistant tabs.
- .github/workflows/android.yml : GitHub Actions workflow to build an unsigned APK and upload as artifact.
- README with instructions.

Important: I cannot build an APK inside this environment. Instead this package includes a complete GitHub Actions workflow that will build the APK automatically when you push this repo to GitHub (you can download the APK artifact).

Steps to get a downloadable APK (two options):
1) Build locally:
   - Open android_app in Android Studio and build -> Generate Signed Bundle / APK.
   - Install on device via USB or use 'adb install'.

2) Build via GitHub (recommended for easy downloadable APK):
   - Create a new GitHub repo, push the contents of this package.
   - On GitHub, go to Actions -> run the 'android-build' workflow or push to trigger it.
   - The workflow will produce an 'app-release-unsigned.apk' artifact you can download.
   - Optionally sign the APK locally before installing (instructions provided).

Security note:
- Do NOT hardcode your OpenAI API key. Use the Settings tab to paste the key locally for testing or deploy a backend proxy and set the workflow secrets if needed.
