from fastapi import FastAPI, Request, HTTPException
import os, httpx

app = FastAPI(title="OpenAI Proxy (example)")

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY', None)
if not OPENAI_API_KEY:
    raise RuntimeError('Set OPENAI_API_KEY environment variable before running the proxy.')

@app.post('/v1/chat/completions')
async def proxy_chat(request: Request):
    body = await request.json()
    async with httpx.AsyncClient(timeout=30) as client:
        headers = {
            'Authorization': f'Bearer {OPENAI_API_KEY}',
            'Content-Type': 'application/json'
        }
        resp = await client.post('https://api.openai.com/v1/chat/completions', json=body, headers=headers)
        if resp.status_code >= 400:
            raise HTTPException(status_code=resp.status_code, detail=resp.text)
        return resp.json()
