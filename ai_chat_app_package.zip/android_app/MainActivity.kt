package com.example.ai_chat_app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

data class ChatMsg(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize with your key: replace with secure retrieval in production
        OpenAIService.init(System.getenv("OPENAI_API_KEY") ?: "YOUR_API_KEY")
        setContent { ChatApp() }
    }
}

@Composable
fun ChatApp() {
    val coroutineScope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMsg>() }
    var loading by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("AI Chat") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(modifier = Modifier.weight(1f).padding(8.dp)) {
                items(messages) { msg ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(text = if (msg.role=="user") "You" else "AI", style = MaterialTheme.typography.subtitle2)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = msg.content, style = MaterialTheme.typography.body1)
                        }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                TextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Type a message") })
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = {
                    val userText = input.trim()
                    if (userText.isEmpty()) return@Button
                    messages.add(ChatMsg("user", userText))
                    input = ""
                    loading = true
                    coroutineScope.launch {
                        try {
                            val req = ChatRequest(messages = listOf(Message("system","You are a helpful assistant."), Message("user", userText)))
                            val res = OpenAIService.api.createChat(req)
                            val aiText = res.choices?.firstOrNull()?.message?.content ?: "No response"
                            messages.add(ChatMsg("assistant", aiText))
                        } catch (e: Exception) {
                            messages.add(ChatMsg("assistant", "Error: ${e.message}"))
                        } finally {
                            loading = false
                        }
                    }
                }, enabled = !loading) {
                    Text(if (loading) "Waiting..." else "Send")
                }
            }
        }
    }
}
