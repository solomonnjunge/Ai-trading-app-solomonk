AI Chat App Package
-------------------

Contents:
- android_app/: Kotlin + Jetpack Compose Android app source skeleton
- backend_proxy/: Example FastAPI proxy to keep your OpenAI API key on server-side
- ON_DEVICE.md: Notes on running a local LLM on Android (advanced)
- README.md: This file (setup instructions below)

Important security note (official guidance):
OpenAI recommends routing requests through your own backend server to keep the API key secure and never deploying a secret in client-side apps. See: https://platform.openai.com/docs/api-reference/chat and https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety.
