package com.example.ai_chat_app

import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

data class Message(val role: String, val content: String)
data class ChatRequest(val model: String = "gpt-4o-mini", val messages: List<Message>, val max_tokens: Int? = 512)
data class Choice(val index: Int, val message: Message?)
data class ChatResponse(val id: String?, val choices: List<Choice>?, val object_: String?)

interface OpenAIApi {
    @POST("v1/chat/completions")
    suspend fun createChat(@Body req: ChatRequest): ChatResponse
}

object OpenAIService {
    private var apiKey: String = ""
    private var baseUrl: String = "https://api.openai.com/"

    fun init(key: String, base: String? = null) {
        apiKey = key
        if (!base.isNullOrEmpty()) baseUrl = base
    }

    private val client: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
        val auth = Interceptor { chain ->
            val req = chain.request().newBuilder()
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .build()
            chain.proceed(req)
        }
        OkHttpClient.Builder().addInterceptor(auth).addInterceptor(logging).build()
    }

    val api: OpenAIApi by lazy {
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(OpenAIApi::class.java)
    }
}
